================================================================
  GLOBAL TIN VALIDATOR  -  100% Offline
  Validate Tax Identification Numbers against country rules
================================================================

Thank you for downloading the Global TIN Validator. It runs entirely
in your web browser - nothing is installed, and no data ever leaves
your computer.


----------------------------------------------------------------
WHAT'S IN THIS FOLDER
----------------------------------------------------------------

  Global-Tin-Validator-Offline.html   The application (open this)
  xlsx.full.min.js                     Excel engine - REQUIRED
  validation-rules.json                The country rule set (440 rules)
  tin-data-test.xlsx                   Sample dataset to try bulk mode
  Global-TIN-Validator-User-Guide.pdf  Full illustrated user guide
  README.txt                           This file

  IMPORTANT: Keep all files together in the same folder.
  If you move the HTML file away from xlsx.full.min.js, Excel
  import/export will stop working.


----------------------------------------------------------------
QUICK START
----------------------------------------------------------------

  1. Double-click "Global-Tin-Validator-Offline.html".
     It opens in your default web browser.

  2. LOAD THE RULES (required every time you open the app):
     - Scroll to the "BULK UPLOAD VALIDATION" section.
     - Click the gear tile ("Configuration / Regex Rules").
     - Select "validation-rules.json".
     - You should see "440 rule(s) loaded".

  3. You're ready to validate.


----------------------------------------------------------------
CHECK A SINGLE TIN
----------------------------------------------------------------

  - Choose the TIN Type (Individual or Entity).
  - Enter the 2-letter country code (e.g. DE, US, NO).
  - Enter the TIN and click "INITIATE SINGLE VALIDATION".

  Result colours:
     VALID     - matches a rule pattern
     INVALID   - format does not match
     NO RULE   - no pattern exists for that country/type


----------------------------------------------------------------
CHECK A WHOLE FILE (BULK)
----------------------------------------------------------------

  - Make sure the rules are loaded (step 2 above).
  - Click the folder tile and upload a CSV or Excel (.xlsx) file.
  - Your file must contain these columns (names are matched
    flexibly - capitalisation and spacing are ignored):

        Country Code    (required)   e.g. NO
        TIN Type        (required)   Individual or Entity
        Tax Identification Number (required)  the number

  - Click "INITIATE BULK VALIDATION".
  - Review the statistics, then download results as CSV or XLSX.

  Try it now with the included "tin-data-test.xlsx" (10,000 rows).


----------------------------------------------------------------
GOOD TO KNOW
----------------------------------------------------------------

  - 100% offline: no internet connection is needed.
  - Nothing is saved: the rules must be re-uploaded each time you
    open the app. This is by design - your data stays private.
  - If every check says "Validation rule missing", the rules file
    has not been loaded yet (see Quick Start, step 2).

  For screenshots and full instructions, open
  "Global-TIN-Validator-User-Guide.pdf".

================================================================
