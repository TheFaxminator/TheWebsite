========================================================================
  THEFAXMINATOR'S XSD SCHEMA VALIDATOR  —  100% Offline
========================================================================

WHAT IT DOES
------------
Validates an XML document against one or more XSD schema files and tells
you clearly whether it is VALID or INVALID. When it is invalid, it lists
each error with a line number and a plain-language message.

This is REAL schema validation (it checks the XML actually conforms to
the rules in your XSD), not just a "is the XML well-formed?" check. It is
powered by libxml2 v2.13.8 — the same engine behind the standard
`xmllint` tool — compiled to WebAssembly so it runs right inside your
browser.


HOW TO OPEN IT (NO INSTALL NEEDED)
----------------------------------
1. Unzip this folder anywhere on your computer.
2. Double-click  index.html  — it opens in your default web browser.

That's it. There is nothing to install: no Python, no Java, no Node,
no server. It works with no internet connection.

Tested in Chrome, Edge and Firefox.

New here?  Open  XSD-Schema-Validator-User-Guide.pdf  for a short,
illustrated walkthrough (it opens in any web browser or PDF reader).


HOW TO USE IT
-------------
1. Drop your XML file onto the left "XML file to validate" box.
2. Drop your schema onto the right "XSD schema file(s)" box. You can add:
     - a single .xsd file, or
     - several .xsd files at once (for schemas that use
       <xs:import> / <xs:include> to pull in other schemas), or
     - a .zip of a whole schema package (it is unzipped in your browser).
3. If several schemas are loaded, pick the main/entry-point schema from
   the dropdown (the tool tries to auto-detect it for you).
4. Click "Validate".

The result panel shows a big VALID / INVALID banner, the list of errors
(if any), and exactly which schema files were used.


TRY THE INCLUDED SAMPLES
------------------------
A /samples folder is included so you can see it working immediately:

  samples/note.xsd            + note-valid.xml     -> VALID
  samples/note.xsd            + note-invalid.xml   -> INVALID (2 errors)

  Multi-file schema with <xs:import> (in samples/multi-file-import/):
  invoice.xsd + currency.xsd  + invoice-valid.xml   -> VALID
  invoice.xsd + currency.xsd  + invoice-invalid.xml -> INVALID
       (drop BOTH .xsd files together, then the XML)


PRIVACY
-------
Everything happens locally, inside your browser. Your XML and schema
files are NEVER uploaded anywhere. There are no servers, no analytics,
and no network calls of any kind. This makes it safe for sensitive or
confidential documents (e.g. tax / compliance reporting data).


ADDING OFFICIAL SCHEMA PACKAGES (optional)
------------------------------------------
Standards such as OECD CRS, OECD CbC and IRS FATCA ship their XSDs as
downloadable packages (often a .zip with several files). To validate
against one:
   - download the official schema package from the relevant authority,
   - drop its .zip (or its .xsd files) onto the schema box.
Always confirm the schema VERSION matches what your reporting authority
currently requires — official schemas do get updated over time.

If you want them built in, drop the schema folders into a /schemas
subfolder next to index.html for easy access; they are not bundled here
so that this tool stays small and version-neutral.


WHAT'S IN THIS FOLDER
---------------------
  index.html                     The app — open this.
  assets/styles.css              Styling.
  assets/app.js                  App logic (file handling, results).
  assets/xmllint.js              libxml2/xmllint engine (glue code).
  assets/xmllint-wasm-data.js    The libxml2 WebAssembly binary itself.
                                 (Embedded as text so the tool works when
                                 opened directly from file:// with no
                                 server. Do not delete or rename it.)
  assets/fflate.min.js           Zip unpacking library (for .zip uploads).
  samples/                       Ready-to-try example files.
  README.txt                     This file.
  XSD-Schema-Validator-User-Guide.pdf
                                 Illustrated user guide — open in any
                                 web browser or PDF reader.


CREDITS / LICENCES
------------------
  libxml2            — MIT Licence (© Daniel Veillard and contributors)
  xmllint-wasm 5.2.0 — MIT Licence (WebAssembly build of xmllint)
  fflate 0.8.3       — MIT Licence (zip handling)

Supports XSD 1.0 (the version used by virtually all official reporting
schemas, including OECD CRS/CbC and IRS FATCA).
========================================================================
