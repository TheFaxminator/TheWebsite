/* ─────────────────────────────────────────────────────────────
   THEFAXMINATOR'S XSD Schema Validator — app logic
   Runs entirely on the main thread over file:// with no fetch:
   - libxml2 (xmllint-wasm) is driven directly via the global
     `Module` factory, with the wasm supplied as `wasmBinary`.
   - Zip packages are unzipped in-browser with fflate.
   Nothing ever leaves the browser.
   ───────────────────────────────────────────────────────────── */
(function () {
  'use strict';

  // ── State ──────────────────────────────────────────────────
  /** @type {{name:string, path:string, size:number, contents:string}|null} */
  let xmlFile = null;
  /** Map keyed by relative path -> {name, path, size, contents} */
  const xsdFiles = new Map();
  let wasmBinary = null;      // Uint8Array, decoded once

  // ── DOM refs ───────────────────────────────────────────────
  const $ = (id) => document.getElementById(id);
  const xmlDrop = $('xml-drop'), xsdDrop = $('xsd-drop');
  const xmlInput = $('xml-input'), xsdInput = $('xsd-input');
  const xmlSection = $('xml-section'), xsdSection = $('xsd-section');
  const xmlListEl = $('xml-list'), xsdListEl = $('xsd-list');
  const entryRow = $('entry-row'), entrySelect = $('entry-select'), entryNote = $('entry-note');
  const errorBox = $('error-box');
  const validateBtn = $('validate-btn'), resetBtn = $('reset-btn');
  const loading = $('loading'), loadingText = $('loading-text');
  const results = $('results'), resultBanner = $('result-banner'), resultMeta = $('result-meta');
  const errorsWrap = $('errors-wrap'), errorsList = $('errors-list'), errorsCount = $('errors-count');
  const rawToggle = $('raw-toggle'), rawOutput = $('raw-output');

  // ── Helpers ────────────────────────────────────────────────
  function fmtSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  }
  function baseName(p) { return String(p).split(/[\/\\]/).pop(); }
  function dirName(p) {
    const parts = String(p).split('/');
    parts.pop();
    return parts.join('/');
  }
  // Normalise a relative reference against a base directory (resolves ./ and ../)
  function resolvePath(baseDir, ref) {
    ref = String(ref).replace(/\\/g, '/');
    if (/^[a-z]+:\/\//i.test(ref)) return ref; // absolute URL — left as-is
    const stack = ref.startsWith('/') ? [] : baseDir.split('/').filter(Boolean);
    for (const seg of ref.split('/')) {
      if (seg === '' || seg === '.') continue;
      if (seg === '..') stack.pop();
      else stack.push(seg);
    }
    return stack.join('/');
  }
  function escapeHtml(s) {
    return String(s).replace(/[&<>"']/g, (c) =>
      ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }
  function showError(html, isWarning) {
    errorBox.innerHTML = html;
    errorBox.classList.toggle('warn', !!isWarning);
    errorBox.classList.add('visible');
  }
  function clearError() { errorBox.classList.remove('visible'); errorBox.innerHTML = ''; }

  // ── Engine: decode wasm once, then run xmllint per validation ─
  function getWasmBinary() {
    if (wasmBinary) return wasmBinary;
    const b64 = window.XMLLINT_WASM_BASE64;
    if (!b64) throw new Error('WASM data failed to load (assets/xmllint-wasm-data.js missing).');
    const bin = atob(b64);
    const len = bin.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = bin.charCodeAt(i);
    wasmBinary = bytes;
    return wasmBinary;
  }

  /**
   * Run the vendored xmllint on a set of virtual files.
   * @param {{fileName:string, contents:string}[]} inputFiles
   * @param {string[]} args
   * @returns {Promise<{exitCode:number, stdout:string, stderr:string}>}
   */
  function runXmllint(inputFiles, args) {
    const factory = window.createXmllintModule || window.Module;
    if (typeof factory !== 'function') {
      return Promise.reject(new Error('Validation engine failed to load (assets/xmllint.js).'));
    }
    return new Promise((resolve, reject) => {
      let stdout = '', stderr = '';
      let settled = false;
      const done = (r) => { if (!settled) { settled = true; resolve(r); } };
      const fail = (e) => { if (!settled) { settled = true; reject(e instanceof Error ? e : new Error(String(e))); } };
      try {
        const ret = factory({
          wasmBinary: getWasmBinary(),
          inputFiles,
          arguments: args,
          print: (t) => { stdout += t + '\n'; },
          printErr: (t) => { stderr += t + '\n'; },
          onExit: (code) => done({ exitCode: code, stdout, stderr }),
          onAbort: (reason) => done({ exitCode: -1, stdout, stderr: 'WASM abort: ' + reason }),
        });
        // The factory returns a promise that rejects if module init fails (e.g. a
        // virtual-FS write error). Observe it so such failures surface instead of
        // hanging the callback-only flow.
        Promise.resolve(ret).catch(fail);
      } catch (e) { fail(e); }
    });
  }

  // ── Schema dependency analysis (for entry-point guess + missing refs) ─
  // Returns { refs: [{from, ref, resolved}], referencedPaths: Set }
  const IMPORT_RE = /<xs(?:d)?:(?:import|include|redefine|override)\b[^>]*\bschemaLocation\s*=\s*(["'])(.*?)\1/gi;
  function analyzeSchemas() {
    const referenced = new Set();
    const allRefs = [];
    for (const f of xsdFiles.values()) {
      const baseDir = dirName(f.path);
      let m;
      IMPORT_RE.lastIndex = 0;
      while ((m = IMPORT_RE.exec(f.contents)) !== null) {
        const ref = m[2].trim();
        if (!ref) continue;
        const isUrl = /^[a-z]+:\/\//i.test(ref);
        const resolved = isUrl ? ref : resolvePath(baseDir, ref);
        allRefs.push({ from: f.path, ref, resolved, isUrl });
        if (!isUrl) referenced.add(resolved);
      }
    }
    return { allRefs, referenced };
  }

  // Find the uploaded schema a (relative) reference resolves to. Matches by full
  // resolved path first, then falls back to basename. Returns the file's path or null.
  function resolveRefToPath(fromDir, ref) {
    if (/^[a-z]+:\/\//i.test(ref)) return null;
    const resolved = resolvePath(fromDir, ref);
    if (xsdFiles.has(resolved)) return resolved;
    const base = baseName(resolved);
    for (const p of xsdFiles.keys()) if (baseName(p) === base) return p;
    return null;
  }

  // The Emscripten virtual FS does not auto-create parent directories, so nested
  // paths (common in zipped schema packages) can't be written directly. Instead we
  // lay every file out flat at the FS root under a unique basename, and rewrite each
  // schema's <xs:import>/<xs:include> schemaLocation to point at those flat names.
  // Because we already resolve each reference to a specific uploaded file, the
  // rewrite is exact and independent of the original directory structure.
  function buildFlatLayout() {
    const byPath = new Map(); // original path -> flat FS name
    const used = new Set();
    for (const path of xsdFiles.keys()) {
      const base = baseName(path);
      let flat = base, i = 2;
      while (used.has(flat)) {
        const dot = base.lastIndexOf('.');
        flat = dot > 0 ? base.slice(0, dot) + '_' + i + base.slice(dot) : base + '_' + i;
        i++;
      }
      used.add(flat);
      byPath.set(path, flat);
    }
    return byPath;
  }

  const SCHEMA_LOC_RE = /(<xs(?:d)?:(?:import|include|redefine|override)\b[^>]*?\bschemaLocation\s*=\s*)(["'])(.*?)\2/gi;
  function rewriteSchemaRefs(f, byPath) {
    const baseDir = dirName(f.path);
    return f.contents.replace(SCHEMA_LOC_RE, (full, pre, q, ref) => {
      const target = resolveRefToPath(baseDir, ref.trim());
      if (!target) return full; // URL or unresolved — leave untouched (missing handled separately)
      return pre + q + byPath.get(target) + q;
    });
  }

  // Which uploaded schemas look like a root (not referenced by any other schema)?
  function rootCandidates(referenced) {
    const roots = [];
    for (const path of xsdFiles.keys()) {
      if (!referenced.has(path)) roots.push(path);
    }
    return roots;
  }

  // Parse the XML for xsi:schemaLocation / noNamespaceSchemaLocation hints.
  function schemaHintsFromXml() {
    if (!xmlFile) return [];
    const hints = [];
    const txt = xmlFile.contents;
    let m = /\bxsi:noNamespaceSchemaLocation\s*=\s*(["'])(.*?)\1/i.exec(txt);
    if (m) hints.push(m[2].trim());
    m = /\bxsi:schemaLocation\s*=\s*(["'])(.*?)\1/i.exec(txt);
    if (m) {
      // space-separated tokens: namespace location namespace location ...
      const toks = m[2].trim().split(/\s+/);
      for (let i = 1; i < toks.length; i += 2) if (toks[i]) hints.push(toks[i]);
    }
    return hints;
  }

  // ── Rendering ──────────────────────────────────────────────
  function render() {
    // XML section
    if (xmlFile) {
      xmlSection.classList.add('visible');
      xmlListEl.innerHTML =
        `<div class="file-row">
           <span class="fbadge xml">XML</span>
           <span class="fname">${escapeHtml(xmlFile.name)}</span>
           <span class="fsize">${fmtSize(xmlFile.size)}</span>
           <button class="remove" data-kind="xml" title="Remove">✕</button>
         </div>`;
    } else {
      xmlSection.classList.remove('visible');
      xmlListEl.innerHTML = '';
    }

    // XSD section
    if (xsdFiles.size) {
      xsdSection.classList.add('visible');
      const { referenced } = analyzeSchemas();
      const roots = new Set(rootCandidates(referenced));
      const rows = [];
      for (const f of xsdFiles.values()) {
        const isRoot = roots.has(f.path) && xsdFiles.size > 1;
        const showPath = f.path !== f.name;
        rows.push(
          `<div class="file-row">
             <span class="fbadge xsd">XSD</span>
             <span class="fname">${escapeHtml(f.name)}${showPath ? ` <span class="fpath">${escapeHtml(f.path)}</span>` : ''}</span>
             ${isRoot ? '<span class="fbadge root">root?</span>' : ''}
             <span class="fsize">${fmtSize(f.size)}</span>
             <button class="remove" data-kind="xsd" data-path="${escapeHtml(f.path)}" title="Remove">✕</button>
           </div>`);
      }
      xsdListEl.innerHTML = rows.join('');
    } else {
      xsdSection.classList.remove('visible');
      xsdListEl.innerHTML = '';
    }

    renderEntrySelector();
    validateBtn.disabled = !(xmlFile && xsdFiles.size);
  }

  function renderEntrySelector() {
    if (xsdFiles.size === 0) { entryRow.classList.remove('visible'); return; }

    const { referenced } = analyzeSchemas();
    const roots = rootCandidates(referenced);
    const hints = schemaHintsFromXml().map(baseName);

    // Build options
    const paths = Array.from(xsdFiles.keys());
    entrySelect.innerHTML = paths.map((p) => {
      const f = xsdFiles.get(p);
      return `<option value="${escapeHtml(p)}">${escapeHtml(f.name)}${p !== f.name ? ' (' + escapeHtml(p) + ')' : ''}</option>`;
    }).join('');

    // Decide auto-selection: prefer an XML hint match, else a lone root candidate.
    let auto = null, reason = '';
    const hintMatch = paths.find((p) => hints.includes(baseName(p)));
    if (hintMatch) { auto = hintMatch; reason = `matched the XML's <b>xsi:schemaLocation</b>`; }
    else if (roots.length === 1) { auto = roots[0]; reason = `only schema not imported/included by another`; }
    else if (paths.length === 1) { auto = paths[0]; reason = `the only uploaded schema`; }

    if (auto) { entrySelect.value = auto; }

    // Only surface the selector when there's a genuine choice to make.
    if (paths.length === 1) {
      entryRow.classList.remove('visible');
    } else {
      entryRow.classList.add('visible');
      entryNote.innerHTML = auto
        ? `Auto-detected: <b>${escapeHtml(xsdFiles.get(auto).name)}</b> (${reason}). Change it if that's wrong.`
        : `Could not auto-detect the entry point — please pick the main schema.`;
    }
  }

  // ── File intake ────────────────────────────────────────────
  function addXmlFile(name, contents) {
    xmlFile = { name: baseName(name), path: baseName(name), size: contents.length, contents };
  }
  function addXsdFile(path, contents) {
    path = String(path).replace(/\\/g, '/').replace(/^\.?\//, '');
    xsdFiles.set(path, { name: baseName(path), path, size: contents.length, contents });
  }

  async function readTextFile(file) {
    return await file.text();
  }

  async function handleXsdFileList(fileList) {
    clearError();
    for (const file of fileList) {
      const lower = file.name.toLowerCase();
      // Preserve directory structure when the browser provides it (folder drops / pickers)
      const relPath = (file.webkitRelativePath && file.webkitRelativePath.length)
        ? file.webkitRelativePath : file.name;
      if (lower.endsWith('.zip')) {
        await handleZip(file);
      } else if (lower.endsWith('.xsd')) {
        addXsdFile(relPath, await readTextFile(file));
      } else if (lower.endsWith('.xml')) {
        // Convenience: an .xml dropped on the schema zone is treated as the doc to validate.
        addXmlFile(file.name, await readTextFile(file));
      } else {
        // Unknown extension inside a schema drop — try to read as text XSD anyway if it looks like one.
        const text = await readTextFile(file);
        if (/<xs(?:d)?:schema\b/i.test(text)) addXsdFile(relPath, text);
      }
    }
    render();
  }

  async function handleZip(file) {
    const buf = new Uint8Array(await file.arrayBuffer());
    if (!window.fflate || typeof window.fflate.unzipSync !== 'function') {
      showError('Zip library failed to load — cannot unpack <code>' + escapeHtml(file.name) + '</code>.');
      return;
    }
    let entries;
    try {
      entries = window.fflate.unzipSync(buf);
    } catch (e) {
      showError('Could not unzip <code>' + escapeHtml(file.name) + '</code>: ' + escapeHtml(e.message));
      return;
    }
    const dec = new TextDecoder('utf-8');
    let added = 0;
    for (const [entryPath, data] of Object.entries(entries)) {
      if (!data || !data.length) continue;             // skip directory entries
      if (/(^|\/)__MACOSX\//.test(entryPath)) continue; // skip mac cruft
      const lower = entryPath.toLowerCase();
      if (lower.endsWith('.xsd')) { addXsdFile(entryPath, dec.decode(data)); added++; }
      else if (lower.endsWith('.xml') && !xmlFile) { addXmlFile(baseName(entryPath), dec.decode(data)); }
    }
    if (!added) {
      showError('No <code>.xsd</code> files found inside <code>' + escapeHtml(file.name) + '</code>.', true);
    }
  }

  // ── Validation ─────────────────────────────────────────────
  async function validate() {
    clearError();
    results.classList.remove('visible');
    if (!xmlFile || !xsdFiles.size) return;

    const rootPath = entrySelect.value || Array.from(xsdFiles.keys())[0];

    // 1) Proactively check that every relative import/include target is present.
    const { allRefs } = analyzeSchemas();
    const havePaths = new Set(xsdFiles.keys());
    const haveBase = new Set(Array.from(xsdFiles.keys()).map(baseName));
    const missing = [];
    const urlRefs = [];
    for (const r of allRefs) {
      if (r.isUrl) { urlRefs.push(r); continue; }
      if (!havePaths.has(r.resolved) && !haveBase.has(baseName(r.resolved))) {
        missing.push(r);
      }
    }
    if (missing.length) {
      const items = missing.map((r) =>
        `<li><code>${escapeHtml(r.ref)}</code> — referenced by <code>${escapeHtml(baseName(r.from))}</code></li>`).join('');
      showError(
        `<h3>Missing schema file${missing.length > 1 ? 's' : ''}</h3>
         The following <code>&lt;xs:import&gt;</code>/<code>&lt;xs:include&gt;</code> reference(s) could not be found among the uploaded files. Add them and try again:
         <ul>${items}</ul>`);
      return;
    }

    setLoading(true, 'Validating…');
    validateBtn.disabled = true;

    // 2) Build a flat virtual FS: every schema under a unique basename (with its
    //    references rewritten to match), plus the XML. Avoids the nested-directory
    //    limitation of the Emscripten FS while keeping cross-file resolution correct.
    const byPath = buildFlatLayout();
    const usedNames = new Set(byPath.values());
    // Keep the XML's FS name distinct from any schema name and free of a leading '-'
    // (which xmllint would treat as a command-line option).
    let xmlName = baseName(xmlFile.name).replace(/^-+/, '_');
    while (usedNames.has(xmlName)) xmlName = '_' + xmlName;

    const inputFiles = [];
    for (const f of xsdFiles.values()) {
      inputFiles.push({ fileName: byPath.get(f.path), contents: rewriteSchemaRefs(f, byPath) });
    }
    inputFiles.push({ fileName: xmlName, contents: xmlFile.contents });

    const args = ['--schema', byPath.get(rootPath), '--noout', xmlName];

    let res;
    try {
      res = await runXmllint(inputFiles, args);
    } catch (e) {
      setLoading(false);
      validateBtn.disabled = false;
      showError('Validation engine error: ' + escapeHtml(e.message));
      return;
    }
    setLoading(false);
    validateBtn.disabled = false;
    renderResults(res, rootPath, urlRefs);
  }

  function renderResults(res, rootPath, urlRefs) {
    results.classList.add('visible');
    results.scrollIntoView({ behavior: 'smooth', block: 'nearest' });

    const rawText = (res.stderr || '') + (res.stdout || '');
    rawOutput.textContent = rawText.trim() || '(no output)';
    rawOutput.classList.remove('visible');
    rawToggle.textContent = 'Show raw xmllint output';

    // exit 0 = valid; 3/4 = validation errors; other = engine error
    const valid = res.exitCode === 0;
    const engineError = res.exitCode !== 0 && res.exitCode !== 3 && res.exitCode !== 4;

    // Banner
    resultBanner.className = 'result-banner ' + (valid ? 'pass' : 'fail');
    if (valid) {
      resultBanner.innerHTML =
        `<span class="status-icon">✅</span>
         <span>VALID<span class="sub">The XML document conforms to the schema.</span></span>`;
    } else if (engineError) {
      resultBanner.innerHTML =
        `<span class="status-icon">⚠️</span>
         <span>COULD NOT VALIDATE<span class="sub">The schema or document could not be processed — see details below.</span></span>`;
    } else {
      resultBanner.innerHTML =
        `<span class="status-icon">❌</span>
         <span>INVALID<span class="sub">The XML document does not conform to the schema.</span></span>`;
    }

    // Meta: which schema files were used
    const rootName = xsdFiles.get(rootPath) ? xsdFiles.get(rootPath).name : baseName(rootPath);
    const chips = Array.from(xsdFiles.values()).map((f) =>
      `<span class="chip${f.path === rootPath ? ' root' : ''}">${escapeHtml(f.path === rootPath ? f.name + '  (root)' : f.name)}</span>`).join('');
    let metaHtml =
      `<div><b>Document:</b> <span class="chip">${escapeHtml(xmlFile.name)}</span></div>
       <div style="margin-top:6px"><b>Schema file(s) used:</b> ${chips}</div>`;
    if (urlRefs && urlRefs.length) {
      const urls = urlRefs.map((r) => `<code>${escapeHtml(r.ref)}</code>`).join(', ');
      metaHtml += `<div style="margin-top:8px;color:var(--yellow)">Note: the schema references remote location(s) ${urls}. ` +
        `These are not fetched (offline) — resolution relies on the files you provided.</div>`;
    }
    resultMeta.innerHTML = metaHtml;

    // Error list
    const errors = parseErrors(res.stderr || '');
    if (errors.length) {
      errorsWrap.style.display = '';
      errorsCount.textContent = `${errors.length} validation ${errors.length === 1 ? 'error' : 'errors'}`;
      errorsList.innerHTML = errors.map((e) => {
        const loc = e.loc
          ? `<span class="file">${escapeHtml(e.loc.fileName)}</span><span class="line">line ${e.loc.lineNumber}</span>`
          : `<span class="line">—</span>`;
        return `<div class="err-item${e.loc ? '' : ' notice'}">
                  <div class="err-loc">${loc}</div>
                  <div class="err-msg">${escapeHtml(e.message)}</div>
                </div>`;
      }).join('');
    } else {
      errorsWrap.style.display = 'none';
      errorsList.innerHTML = '';
    }
  }

  // Parse xmllint stderr into structured errors (mirrors xmllint-wasm's own parser).
  function parseErrors(output) {
    return output.split('\n').map((line) => {
      if (!line.trim()) return null;
      // "file:line: message"
      const m = /^(.*?):(\d+):\s*(.*)$/.exec(line);
      if (m) {
        return { rawMessage: line, message: m[3].trim(), loc: { fileName: m[1], lineNumber: parseInt(m[2], 10) } };
      }
      return { rawMessage: line, message: line.trim(), loc: null };
    }).filter((e) => {
      if (!e) return false;
      // Drop the "<file> validates" / "<file> fails to validate" summary lines.
      const t = e.rawMessage.trim();
      if (/ validates$/.test(t)) return false;
      if (/ fails to validate$/.test(t)) return false;
      return true;
    });
  }

  // ── UI wiring ──────────────────────────────────────────────
  function setLoading(on, text) {
    loading.classList.toggle('visible', on);
    if (text) loadingText.textContent = text;
  }

  function wireDropzone(zone, input, onFiles) {
    zone.addEventListener('click', () => input.click());
    zone.addEventListener('dragover', (e) => { e.preventDefault(); zone.classList.add('drag-over'); });
    zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
    zone.addEventListener('drop', (e) => {
      e.preventDefault();
      zone.classList.remove('drag-over');
      if (e.dataTransfer.files && e.dataTransfer.files.length) onFiles(Array.from(e.dataTransfer.files));
    });
    input.addEventListener('change', () => {
      if (input.files && input.files.length) {
        // Snapshot into an array BEFORE clearing the picker: the async file
        // handler iterates this list across awaits, and resetting input.value
        // empties the live FileList mid-iteration (dropping every file but the
        // first). Copying first makes multi-file selection reliable.
        const files = Array.from(input.files);
        input.value = '';
        onFiles(files);
      }
    });
  }

  wireDropzone(xmlDrop, xmlInput, async (files) => {
    clearError();
    const file = files[0];
    addXmlFile(file.name, await readTextFile(file));
    render();
  });
  wireDropzone(xsdDrop, xsdInput, (files) => handleXsdFileList(files));

  // Remove buttons (event delegation)
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('.remove');
    if (!btn) return;
    if (btn.dataset.kind === 'xml') xmlFile = null;
    else if (btn.dataset.kind === 'xsd') xsdFiles.delete(btn.dataset.path);
    clearError();
    results.classList.remove('visible');
    render();
  });

  entrySelect.addEventListener('change', () => {
    if (entrySelect.value) {
      const f = xsdFiles.get(entrySelect.value);
      entryNote.innerHTML = `Using <b>${escapeHtml(f ? f.name : entrySelect.value)}</b> as the entry point.`;
    }
  });

  rawToggle.addEventListener('click', () => {
    const vis = rawOutput.classList.toggle('visible');
    rawToggle.textContent = vis ? 'Hide raw xmllint output' : 'Show raw xmllint output';
  });

  validateBtn.addEventListener('click', validate);
  resetBtn.addEventListener('click', () => {
    xmlFile = null; xsdFiles.clear();
    clearError();
    results.classList.remove('visible');
    render();
  });

  // Warm up: decode the wasm binary early so the first validation is snappy.
  window.addEventListener('load', () => {
    try { getWasmBinary(); } catch (_) { /* surfaced on first validate */ }
  });

  render();
})();
